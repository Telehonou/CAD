Recherche multicrit�re----------------------
Url     : http://codes-sources.commentcamarche.net/source/42052-recherche-multicritereAuteur  : linkinparkemDate    : 15/08/2013
Licence :
=========

Ce document intitul� � Recherche multicrit�re � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Ce code permet de faire une recherche avanc&eacute;e dans une base de donn&eacut
e;es selon plusieurs crit&egrave;res &agrave; remplir en les joingnant par des A
ND ou bien OR selon ce qu'on choisit, et c'est pas obligatoire de remplir tous l
es champs (le tout est dans le zip :-) et bonne programmation avec PHP) votre se
rveur Mohammed ENNADI
