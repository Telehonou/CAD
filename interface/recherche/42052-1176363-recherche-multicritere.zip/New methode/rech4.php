<style type="text/css">
.Style2 {
	color: #009900;
	font-weight: bold;
	font-style: italic;
	font-size: 36px;
}
</style>
<?
$nom = $_POST['nom'];
$champ1 = "nom";
$prenom = $_POST['prenom'];
$champ2 = "prenom";
$age = $_POST['age'];
$champ3 = "age";

if($_POST['et_ou1'] == 'AND')
{ 
 if(empty($_POST['nom']))      
 {
 $nom = 1;
 $champ1 = 1;
 }
}
else
{
 if(empty($_POST['nom']))      
 {
 $nom = 1;
 $champ1 = 2;
 }
}

if($_POST['et_ou1'] == 'AND')
{ 
 if(empty($_POST['prenom']))      
 {
  $prenom = 1;
  $champ2 = 1;
 }
}
else
{
 if(empty($_POST['prenom']))      
 {
  $prenom = 1;
  $champ2 = 2;
 }
}

if($_POST['et_ou2'] == 'AND')
{ 
 if(empty($_POST['age']))      
 {
  $age = 1;
  $champ3 = 1;
 }
}
else
{
 if(empty($_POST['age']))      
 {
  $age = 1;
  $champ3 = 2;
 }
}

$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'bd';
$tables = 'personne';

// connection � la DB
mysql_connect ($host,$user,$pass) or die ('Erreur : '.mysql_error() );
mysql_select_db($db) or die ('Erreur :'.mysql_error());

$select = "SELECT * FROM $tables WHERE $champ1 = '$nom' ".$_POST["et_ou1"]." $champ2 = '$prenom' ".$_POST["et_ou2"]." $champ3 = $age";

if($nom=="" AND $prenom=="" AND $age=="")
echo 'Vous devez preciser en moins un crit�re de recherche !!';
else
{
$result = mysql_query($select) or die ('Erreur : '.mysql_error());
$total = mysql_num_rows($result);

if($total) 
{
 echo "<table width=\"435\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
  <!--DWLayoutTable-->
  <tr>
    <td width=\"15\" height=\"19\">&nbsp;</td>
    <td width=\"129\">&nbsp;</td>
    <td width=\"9\">&nbsp;</td>
    <td width=\"126\">&nbsp;</td>
    <td width=\"12\">&nbsp;</td>
    <td width=\"124\">&nbsp;</td>
    <td width=\"20\">&nbsp;</td>
  </tr>";
  echo "<tr>
    <td height=\"22\">&nbsp;</td>
    <td valign=\"top\" bgcolor=\"#6699FF\"><b>nom</b>&nbsp;</td>
    <td>&nbsp;</td>
    <td valign=\"top\" bgcolor=\"#6699FF\"><b>pr�nom</b>&nbsp;</td>
    <td>&nbsp;</td>
    <td valign=\"top\" bgcolor=\"#6699FF\"><b>age</b>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>";
  echo "<tr>
    <td height=\"22\">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>";
  while($row = mysql_fetch_array($result)) 
  {
    echo '<td height="22">&nbsp;</td>
    <td valign="top">'.$row['nom'].'&nbsp;</td>
    <td>&nbsp;</td>
    <td valign="top">'.$row['prenom'].'&nbsp;</td>
    <td>&nbsp;</td>
    <td valign="top">'.$row['age'].'&nbsp;</td>
    <td>&nbsp;</td>
  </tr>';
  }
echo '<tr>
    <td height="157">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>';
}
else echo '<div align="center"><span class="Style1">Aucun r&eacute;sulat ne corresponds &agrave; votre recherche !!... </span>
</div>';

mysql_free_result($result);
mysql_close();
}
?>